<?php

function myName ()
{
    return 'Jati Nirob';
}
