<?php $__env->startSection('body'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div>
                        <img src="<?php echo e(asset($course->image)); ?>" alt="" class="w-100" style="height: 400px">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card card-body">
                        <h3><?php echo e($course->title); ?></h3>
                        <p>Fee: <?php echo e($course->fee); ?></p>
                        <p>
                            <span>Starting Date: <?php echo e($course->starting_date); ?></span>
                            <span> Ending Date: <?php echo e($course->ending_date); ?></span>
                        </p>
                        <p><?php echo e($course->short_description); ?></p>
                        <form action="<?php echo e(route('course-enroll')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="course_id" value="<?php echo e($course->id); ?>">
                            <input type="submit" class="btn btn-primary" <?php echo e($hasEnroll == true ? 'disabled' : ''); ?>  value="Enroll">
                        </form>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md-12">
                    <div>
                        <?php echo $course->long_description; ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ssms-batch-six\resources\views/front/course/details.blade.php ENDPATH**/ ?>