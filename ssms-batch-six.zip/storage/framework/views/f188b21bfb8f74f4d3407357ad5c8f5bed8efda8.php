<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Enroll Message</title>
</head>
<body>
    <h2>To : <?php echo e($user->name); ?></h2>
    <p>course id: <?php echo e($enroll->id); ?></p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus cumque dignissimos, ea eius est, expedita molestiae nulla quia quod reprehenderit repudiandae sapiente tempore veritatis. Ad cum dolorem harum iure quidem!</p>
    <button type="button">Hello</button>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ssms-batch-six\resources\views/front/invoice.blade.php ENDPATH**/ ?>