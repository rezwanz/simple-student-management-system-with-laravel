<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-center">All Enrolled Courses</h4>
                </div>
                <div class="card-body">
                    <table class="table table-responsive table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Course Name</th>
                                <th>Student Name</th>
                                <th>Enroll Date</th>
                                <th>Course Fee</th>
                                <th>Payment Method</th>
                                <th>Payment Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $enrolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($enroll->course->title); ?></td>
                                <td><?php echo e($enroll->user->name); ?></td>
                                <td><?php echo e($enroll->enroll_date); ?></td>
                                <td><?php echo e($enroll->course->fee); ?></td>
                                <td><?php echo e($enroll->payment_method == 1 ? 'Cash' : "SSLCommerz"); ?></td>
                                <td><?php echo e($enroll->payment_status); ?></td>
                                <td>
                                    <a href="<?php echo e(route('change-payment-status', ['id' => $enroll->id])); ?>" class="btn btn-primary btn-sm">status</a>
                                    <a href="" class="btn btn-danger btn-sm">delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ssms-batch-six\resources\views/admin/enroll/manage.blade.php ENDPATH**/ ?>