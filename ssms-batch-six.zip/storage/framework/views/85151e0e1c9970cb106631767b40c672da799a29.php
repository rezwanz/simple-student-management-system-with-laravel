<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-center">Manage Courses</h4>
                </div>
                <div class="card-body">
                    <table class="table table-responsive table-bordered w-100">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Title</th>
                            <th>Starting Date</th>
                            <th>Ending Date</th>
                            <th>Fee</th>
                            <th>Short Description</th>
                            <th>Long Description</th>
                            <th>Image</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($course->title); ?></td>
                                <td><?php echo e($course->starting_date); ?></td>
                                <td><?php echo e($course->ending_date); ?></td>
                                <td><?php echo e($course->fee); ?></td>
                                <td><?php echo e($course->short_description); ?></td>
                                <td><?php echo $course->long_description; ?></td>
                                <td>
                                    <img src="<?php echo e(asset($course->image)); ?>" alt="" style="height: 80px; width: 80px;">
                                </td>
                                <td><?php echo e($course->status == 1 ? 'Active' : 'Inactive'); ?></td>
                                <td>
                                    <a href="<?php echo e(route('courses.change-status', ['id' => $course->id])); ?>" class="btn btn-secondary">status</a>
                                    <a href="<?php echo e(route('courses.edit', $course->id)); ?>" class="btn btn-primary">edit</a>
                                    <form action="<?php echo e(route('courses.destroy', $course->id)); ?>" method="post" style="display: inline-block" onsubmit="return confirm('Are you sure?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <input type="submit" class="btn btn-danger" value="delete">
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ssms-batch-six\resources\views/admin/course/manage.blade.php ENDPATH**/ ?>